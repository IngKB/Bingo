#!/bin/bash

# stop dotnet application
systemctl stop kestrel-aspnetcoreapp.service