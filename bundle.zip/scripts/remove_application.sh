#!/bin/bash
rm -rf /home/ubuntu/bingoapp